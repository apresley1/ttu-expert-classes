﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using WebApplication1.Entity;

namespace WebApplication1.Controllers
{
    public class UserController : ApiController
    {
        // GET: api/User
        [HttpGet]
        public IEnumerable<UserEntity> Get()
        {
            return GetAllUsers();
        }

        // GET: api/User/5
        [HttpGet]
        public HttpResponseMessage Get(int id)
        {
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, this.GetUserById(id));
            }
            catch
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotFound);
                response.Content = new StringContent("User not found");
                return response;
            }
        }

        // POST: api/User
        [HttpPost]
        public HttpResponseMessage Post([FromBody] UserEntity user)
        {
            var response = new HttpResponseMessage(HttpStatusCode.NotImplemented);
            var message = string.Format("{0}{1}{1}{2}", "POST NOT IMPLEMENTED", System.Environment.NewLine, JsonConvert.SerializeObject(user));
            response.Content = new StringContent(message);
            return response;
        }

        // PUT: api/User/5
        [HttpPut]
        public HttpResponseMessage Put(int id, [FromBody] UserEntity user)
        {
            var response = new HttpResponseMessage(HttpStatusCode.NotImplemented);
            var message = string.Format("{0}{1}{1}{2}", "PUT NOT IMPLEMENTED", System.Environment.NewLine, JsonConvert.SerializeObject(user));
            response.Content = new StringContent(message);
            return response;
        }

        // DELETE: api/User/5
        [HttpDelete]
        public HttpResponseMessage Delete(int id)
        {
            try
            {
                this.DeleteUserById(id);

                var response = new HttpResponseMessage(HttpStatusCode.OK);
                var message = string.Format("{0}{1}{1}{2}{3}", "Successfully Deleted", System.Environment.NewLine, "Record found for id: ", id);
                response.Content = new StringContent(message);
                return response;
            }
            catch
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotFound);
                var message = string.Format("{0}{1}{1}{2}{3}", "Delete Failed", System.Environment.NewLine, "Record NOT found for id: ", id);
                response.Content = new StringContent(message);
                return response;
            }
        }



        // EMULATE SERVICE CLASS BELOW
        ICollection<UserEntity> users = new Collection<UserEntity> { };

        private void HydrateUsersCollection()
        {
            var architectureProject     = new ProjectEntity { Id = 1, Name = "Architecture" };
            var forecastingProject      = new ProjectEntity { Id = 2, Name = "Forecasting" };
            var erpProject              = new ProjectEntity { Id = 3, Name = "ERP" };
            var sqlProject              = new ProjectEntity { Id = 4, Name = "SQL" };

            var u1 = new UserEntity
            {
                Id = 1,
                FirstName = "Paul",
                LastName = "Cordero",
                Company = "Truno",
                EMail = "pcordero@truno.com",
                Phone = "1.800.657.7108"
            };
            var u1Projects = new Collection<ProjectEntity>();
            u1Projects.Add(architectureProject);
            u1Projects.Add(forecastingProject);
            u1Projects.Add(erpProject);

            u1.Projects = u1Projects;
            this.users.Add(u1);

            var u2 = new UserEntity
            {
                Id = 2,
                FirstName = "Will",
                LastName = "Buckley",
                Company = "Truno",
                EMail = "wbuckley@truno.com",
                Phone = "1.800.657.7108"
            };
            var u2Projects = new Collection<ProjectEntity>();
            u2Projects.Add(erpProject);
            u2Projects.Add(sqlProject);

            u2.Projects = u2Projects;
            this.users.Add(u2);
        }

        private IEnumerable<UserEntity> GetAllUsers()
        {
            this.HydrateUsersCollection();

            return this.users;
        }

        private UserEntity GetUserById(int id)
        {
            this.HydrateUsersCollection();

            return this.users.First(x => x.Id == id);
        }

        private void DeleteUserById(int id)
        {
            this.HydrateUsersCollection();

            var user = this.users.First(x => x.Id == id);
            // DELETE USER
        }
        
    }
}
