install.packages("dplyr")
install.packages("lubridate")
install.packages("xlsx")
require(dplyr)
require(lubridate)
require(tidyr)
require(xlsx)


# Reformat date variables
ticket=read.csv("ticketData.csv")
ticket$Created.Time=as.POSIXct(ticket$Created.Time,format="%Y-%m-%d %H:%M:%S")
ticket$Due.by.Time=as.POSIXct(ticket$Due.by.Time,format="%Y-%m-%d %H:%M:%S")
ticket$Resolved.Time=as.POSIXct(ticket$Resolved.Time,format="%Y-%m-%d %H:%M:%S")
ticket$Closed.Time=as.POSIXct(ticket$Closed.Time,format="%Y-%m-%d %H:%M:%S")
ticket$Last.Updated.Time=as.POSIXct(ticket$Last.Updated.Time,format="%Y-%m-%d %H:%M:%S")
ticket$Initial.Response.Time=as.POSIXct(ticket$Initial.Response.Time,format="%Y-%m-%d %H:%M:%S")

# Gather
tickets_spread=read.csv("messy.csv")
tickets_tidy<-tickets_spread%>%
  gather(`Billing`,`Level.1.Support`,`Level.2.HCM`,`Level.3.HCM`,`Sales`,`Support`,key="Level",value="Created.Tickets")

# Arrange
tickets_spread_top<-ticket %>%
  group_by(Agent,Group)%>%
  summarise(Created.Tickets=n())%>%
  arrange(desc(Created.Tickets))%>%
  top_n(1) #select 1st rank from each group

# Group by, Filter and Summarize
resolution_time_by_priority<-ticket %>%
  group_by(Priority) %>%
  filter(!is.na(Resolved.Time)) %>%
  summarise(Avg.resolution.time.hrs=mean(difftime(Resolved.Time,Created.Time,units=c("mins"))/60),ntickets=n())


tickets_per_hour_level<-ticket %>%
  group_by(Hour.of.day=hour(Created.Time),Group)%>%
  summarise(Created.tickets=n())

# Spread
tickets_per_hour_level<-tickets_per_hour_level%>%spread(Group,Created.tickets)
tickets_per_hour_level[is.na(tickets_per_hour_level)]<-0

# Categorize everything other than L1, L2 and L3 to 'Others'
tickets_per_hour_level<-mutate(tickets_per_hour_level,Others=(Billing+Sales+Support))

# Select
tickets_per_hour_level<-tickets_per_hour_level%>%
  select(Hour.of.day,`Level 1 Support`,`Level 2 HCM`,`Level 3 HCM`,Others)
